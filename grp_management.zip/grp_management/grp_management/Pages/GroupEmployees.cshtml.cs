using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using grp_management.Data;
using grp_management.Models;
using System.ComponentModel.DataAnnotations;
using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;

namespace grp_management.Pages
{
    [Authorize]
    public class GroupEmployeesModel : PageModel
    {
        private readonly AppDbContext _context;
        private readonly IHttpContextAccessor _httpContextAccessor;

        public GroupEmployeesModel(AppDbContext context, IHttpContextAccessor httpContextAccessor)
        {
            _context = context;
            _httpContextAccessor = httpContextAccessor;
        }

        [BindProperty(SupportsGet = true)]
        public int? SelectedGroupId { get; set; }

        public SelectList Groups { get; set; } = null!;
        public List<Employee> Employees { get; set; } = new();
        public List<Group> AvailableGroupsToJoin { get; set; } = new();

        public async Task<IActionResult> OnGetAsync()
        {
            var userIdClaim = _httpContextAccessor.HttpContext?.User.FindFirst(ClaimTypes.NameIdentifier);
            if (userIdClaim == null || !int.TryParse(userIdClaim.Value, out int currentUserId))
            {
                // User not logged in or user ID is invalid, redirect to login
                return RedirectToPage("/Login");
            }

            var userRole = User.FindFirst(ClaimTypes.Role)?.Value;
            var userEmployeeIdClaim = _httpContextAccessor.HttpContext?.User.FindFirst("EmployeeId");
            int? userEmployeeId = null;
            if (userEmployeeIdClaim != null && int.TryParse(userEmployeeIdClaim.Value, out int empId))
            {
                userEmployeeId = empId;
            }

            if (userRole == "Admin")
            {
                // Admins can see all groups
                Groups = new SelectList(await _context.Groups.ToListAsync(), "Id", "Name");
            }
            else // Regular User (Member)
            {
                // Members can only see groups they are part of in their dropdown
                var memberGroups = await _context.GroupEmployees
                    .Where(ge => ge.EmployeeId == userEmployeeId)
                    .Select(ge => ge.Group)
                    .ToListAsync();
                Groups = new SelectList(memberGroups, "Id", "Name");

                // Populate available groups to join for non-admins
                var allGroups = await _context.Groups.ToListAsync();
                var groupsUserIsAlreadyMemberOf = await _context.GroupEmployees
                    .Where(ge => ge.EmployeeId == userEmployeeId)
                    .Select(ge => ge.GroupId)
                    .ToListAsync();

                var pendingRequests = await _context.GroupMembershipRequests
                    .Where(gmr => gmr.EmployeeId == userEmployeeId && gmr.Status == "Pending")
                    .Select(gmr => gmr.GroupId)
                    .ToListAsync();

                AvailableGroupsToJoin = allGroups
                    .Where(g => !groupsUserIsAlreadyMemberOf.Contains(g.Id) && !pendingRequests.Contains(g.Id))
                    .ToList();
            }

            if (SelectedGroupId.HasValue)
            {
                // Get employees for the selected group
                Employees = await _context.GroupEmployees
                    .Where(ge => ge.GroupId == SelectedGroupId)
                    .Include(ge => ge.Employee)
                    .Select(ge => ge.Employee!)
                    .ToListAsync();
            }

            return Page();
        }

        public async Task<IActionResult> OnPostRequestAccessAsync(int groupId)
        {
            var userIdClaim = _httpContextAccessor.HttpContext?.User.FindFirst(ClaimTypes.NameIdentifier);
            if (userIdClaim == null || !int.TryParse(userIdClaim.Value, out int currentUserId))
            {
                return Unauthorized();
            }

            var userEmployeeIdClaim = _httpContextAccessor.HttpContext?.User.FindFirst("EmployeeId");
            if (userEmployeeIdClaim == null || !int.TryParse(userEmployeeIdClaim.Value, out int employeeId))
            {
                return BadRequest("Employee ID not found.");
            }

            // Check if a request already exists or if the user is already a member
            var existingRequest = await _context.GroupMembershipRequests
                .AnyAsync(gmr => gmr.GroupId == groupId && gmr.EmployeeId == employeeId && gmr.Status == "Pending");

            if (existingRequest)
            {
                return RedirectToPage(new { groupId = SelectedGroupId }); // Already requested
            }

            var isMember = await _context.GroupEmployees
                .AnyAsync(ge => ge.GroupId == groupId && ge.EmployeeId == employeeId);

            if (isMember)
            {
                return RedirectToPage(new { groupId = SelectedGroupId }); // Already a member
            }

            var newRequest = new GroupMembershipRequest
            {
                GroupId = groupId,
                EmployeeId = employeeId,
                RequestDate = DateTime.UtcNow,
                Status = "Pending"
            };

            _context.GroupMembershipRequests.Add(newRequest);
            await _context.SaveChangesAsync();

            return RedirectToPage(new { groupId = SelectedGroupId });
        }

        public async Task<IActionResult> OnPostAddEmployeeAsync(
            [Required] string Name,
            [Required, EmailAddress] string Email,
            string? PhoneNumber,
            string? Department,
            string? Position)
        {
            if (!SelectedGroupId.HasValue)
            {
                return BadRequest("No group selected");
            }

            // Only Admins can add employees
            if (!User.IsInRole("Admin"))
            {
                return Forbid(); // Or return Unauthorized()
            }

            // Create new employee
            var employee = new Employee
            {
                Name = Name,
                Email = Email,
                PhoneNumber = PhoneNumber,
                Department = Department,
                Position = Position
            };

            _context.Employees.Add(employee);
            await _context.SaveChangesAsync();

            // Add employee to the selected group
            var groupEmployee = new GroupEmployee
            {
                GroupId = SelectedGroupId.Value,
                EmployeeId = employee.EmpNO
            };

            _context.GroupEmployees.Add(groupEmployee);
            await _context.SaveChangesAsync();

            return RedirectToPage(new { groupId = SelectedGroupId });
        }

        public async Task<IActionResult> OnPostRemoveEmployeeAsync(int employeeId)
        {
            if (!SelectedGroupId.HasValue)
            {
                return BadRequest("No group selected");
            }

            // Only Admins can remove employees
            if (!User.IsInRole("Admin"))
            {
                return Forbid(); // Or return Unauthorized()
            }

            var groupEmployee = await _context.GroupEmployees
                .FirstOrDefaultAsync(ge => ge.GroupId == SelectedGroupId && ge.EmployeeId == employeeId);

            if (groupEmployee != null)
            {
                _context.GroupEmployees.Remove(groupEmployee);
                await _context.SaveChangesAsync();
            }

            return RedirectToPage(new { groupId = SelectedGroupId });
        }
    }
} 