using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using grp_management.Models;
using grp_management.Data;
using System.ComponentModel.DataAnnotations;

namespace grp_management.Pages
{
    public class SendMessageModel : PageModel
    {
        private readonly AppDbContext _context;

        public SendMessageModel(AppDbContext context)
        {
            _context = context;
            Groups = new SelectList(Enumerable.Empty<Group>(), "Id", "Name");
        }

        [BindProperty]
        public InputModel Input { get; set; } = new InputModel();

        public SelectList Groups { get; set; }

        public class InputModel
        {
            [Required]
            public int GroupId { get; set; }

            [Required]
            public string MessageContent { get; set; } = string.Empty;

            [Required]
            public string SentVia { get; set; } = "Email"; // Default to Email
        }

        public async Task OnGetAsync()
        {
            await LoadSelectListsAsync();
        }

        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
            {
                await LoadSelectListsAsync();
                return Page();
            }

            if (Input.GroupId == -1)
            {
                // Send to all groups
                var allGroups = await _context.Groups.ToListAsync();
                foreach (var group in allGroups)
                {
                    var sentMsg = new SentMsg
                    {
                        MessageContent = Input.MessageContent,
                        SentDate = DateTime.UtcNow,
                        SentVia = Input.SentVia,
                        Status = "Sent",
                        GroupId = group.Id,
                    };
                    _context.SentMsgs.Add(sentMsg);
                }
                await _context.SaveChangesAsync();
                return RedirectToPage("/MessageHistory");
            }
            else
            {
                var sentMsg = new SentMsg
                {
                    MessageContent = Input.MessageContent,
                    SentDate = DateTime.UtcNow,
                    SentVia = Input.SentVia,
                    Status = "Sent",
                    GroupId = Input.GroupId,
                };
                _context.SentMsgs.Add(sentMsg);
                await _context.SaveChangesAsync();
                return RedirectToPage("/MessageHistory");
            }
        }

        private async Task LoadSelectListsAsync()
        {
            var groups = await _context.Groups.ToListAsync();
            var groupItems = groups.Select(g => new SelectListItem { Value = g.Id.ToString(), Text = g.Name }).ToList();
            // Add 'All' at the top
            groupItems.Insert(0, new SelectListItem { Value = "-1", Text = "All" });
            Groups = new SelectList(groupItems, "Value", "Text");
        }
    }
} 