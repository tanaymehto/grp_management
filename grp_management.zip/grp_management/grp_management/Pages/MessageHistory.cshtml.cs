using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using grp_management.Models;
using grp_management.Data;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Linq;

namespace grp_management.Pages
{
    public class MessageHistoryModel : PageModel
    {
        private readonly AppDbContext _context;

        public MessageHistoryModel(AppDbContext context)
        {
            _context = context;
        }

        [BindProperty(SupportsGet = true)]
        public string? SearchGroup { get; set; }

        [BindProperty(SupportsGet = true)]
        public string? SearchMessage { get; set; }

        [BindProperty(SupportsGet = true)]
        public string? SearchStatus { get; set; }

        [BindProperty(SupportsGet = true)]
        public string? SearchSentVia { get; set; }

        [BindProperty(SupportsGet = true)]
        public DateTime? SearchDate { get; set; }

        public List<MessageHistoryItem> Messages { get; set; } = new List<MessageHistoryItem>();

        public async Task OnGetAsync()
        {
            var query = _context.SentMsgs
                .Include(m => m.Group)
                .AsQueryable();

            // Apply filters if they are provided
            if (!string.IsNullOrWhiteSpace(SearchGroup))
            {
                query = query.Where(m => m.Group != null && m.Group.Name.Contains(SearchGroup));
            }

            if (!string.IsNullOrWhiteSpace(SearchMessage))
            {
                query = query.Where(m => m.MessageContent.Contains(SearchMessage));
            }

            if (!string.IsNullOrWhiteSpace(SearchStatus))
            {
                query = query.Where(m => m.Status == SearchStatus);
            }

            if (!string.IsNullOrWhiteSpace(SearchSentVia))
            {
                query = query.Where(m => m.SentVia == SearchSentVia);
            }

            if (SearchDate.HasValue)
            {
                var startDate = SearchDate.Value.Date;
                var endDate = startDate.AddDays(1);
                query = query.Where(m => m.SentDate >= startDate && m.SentDate < endDate);
            }

            Messages = await query
                .OrderByDescending(m => m.SentDate)
                .Select(m => new MessageHistoryItem
                {
                    SentDate = m.SentDate,
                    SentVia = m.SentVia,
                    SentTo = m.Group != null ? m.Group.Name : "Unknown",
                    MessageContent = m.MessageContent,
                    Status = m.Status
                })
                .ToListAsync();
        }
    }

    public class MessageHistoryItem
    {
        public DateTime SentDate { get; set; }
        public string SentVia { get; set; } = string.Empty;
        public string SentTo { get; set; } = string.Empty;
        public string MessageContent { get; set; } = string.Empty;
        public string Status { get; set; } = string.Empty;
    }
} 