using Microsoft.AspNetCore.Authentication.Cookies;
using grp_management.Models;
using Microsoft.EntityFrameworkCore;
using System.Security.Cryptography;
using System.Text;
using grp_management.Hubs;
using grp_management.Data;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddRazorPages();

// Add IHttpContextAccessor
builder.Services.AddHttpContextAccessor();

// Add AppDbContext for EF Core
builder.Services.AddDbContext<AppDbContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));

// Add Authentication
builder.Services.AddAuthentication(CookieAuthenticationDefaults.AuthenticationScheme)
    .AddCookie(options =>
    {
        options.LoginPath = "/Login";
        options.LogoutPath = "/Logout";
        options.AccessDeniedPath = "/AccessDenied";
    });

// Add SignalR
builder.Services.AddSignalR();

var app = builder.Build();

// Seed or update sample user and groups
using (var scope = app.Services.CreateScope())
{
    var db = scope.ServiceProvider.GetRequiredService<AppDbContext>();
    // db.Database.Migrate();  // Temporarily disabled migrations

    var adminUser = db.Users.FirstOrDefault(u => u.Username == "admin");
    var password = "password"; // The desired password
    var hashedPassword = Convert.ToBase64String(
        SHA256.Create().ComputeHash(Encoding.UTF8.GetBytes(password)));

    if (adminUser == null)
    {
        // User doesn't exist, create a new one
        adminUser = new User
        {
            Username = "admin",
            Email = "admin@example.com" // Add email or other required properties
        };
        db.Users.Add(adminUser);
    }

    // Always set or update the password hash
    adminUser.PasswordHash = hashedPassword;

    db.SaveChanges();

    // Seed default and specific groups if they don't exist
    var groupNamesToSeed = new List<string>
    {
        "Default Group",
        "DMP",
        "All Executive",
        "Young Executive",
        "Non Executive",
        "Worker",
        "IP Club Member",
        "RC Club Member",
        "Sports Council Members",
        "SMC Members",
        "HODs",
        "GMs",
        "AGMs",
        "Senior Manager and below(combined)"
    };

    foreach (var groupName in groupNamesToSeed)
    {
        if (!db.Groups.Any(g => g.Name == groupName))
        {
            db.Groups.Add(new Group { Name = groupName, Description = $"Group for {groupName}" });
        }
    }

    db.SaveChanges();

    // Seed a default template if none exists
    if (!db.Templates.Any())
    {
        db.Templates.Add(new Template { TemplateName = "Default Template", TemplateMsg = "This is a default message.", TemplateType = "General" });
        db.SaveChanges();
    }
}

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error");
    app.UseHsts();
}
app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

app.UseAuthentication();
app.UseAuthorization();

app.MapRazorPages();
app.MapHub<MessageHub>("/messageHub");

app.Run();
