﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace grp_management.Migrations
{
    /// <inheritdoc />
    public partial class AddMoreGroups : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "GroupMembershipRequests",
                keyColumn: "RequestId",
                keyValue: 1);

            migrationBuilder.DeleteData(
                table: "Employees",
                keyColumn: "EmpNO",
                keyValue: 1);

            migrationBuilder.DeleteData(
                table: "Groups",
                keyColumn: "Id",
                keyValue: 1);

            migrationBuilder.InsertData(
                table: "Employees",
                columns: new[] { "EmpNO", "CreatedAt", "Department", "Email", "Name", "PhoneNumber", "Position", "UpdatedAt" },
                values: new object[,]
                {
                    { -2, new DateTime(2025, 6, 5, 8, 12, 24, 109, DateTimeKind.Utc).AddTicks(5853), "HR", "test.employee2@example.com", "Test Employee 2", null, "Assistant", null },
                    { -1, new DateTime(2025, 6, 5, 8, 12, 24, 109, DateTimeKind.Utc).AddTicks(5846), "IT", "test.employee1@example.com", "Test Employee 1", null, "Developer", null }
                });

            migrationBuilder.InsertData(
                table: "Groups",
                columns: new[] { "Id", "CreatedAt", "CreatedByUserId", "DepartmentRestriction", "Description", "IsPrivate", "MaxMembers", "Name", "UpdatedAt" },
                values: new object[,]
                {
                    { -2, new DateTime(2025, 6, 5, 8, 12, 24, 109, DateTimeKind.Utc).AddTicks(5975), null, "HR", "Another test group", false, 20, "Test Group 2", null },
                    { -1, new DateTime(2025, 6, 5, 8, 12, 24, 109, DateTimeKind.Utc).AddTicks(5969), null, "IT", "A test group for membership requests", true, 10, "Test Group 1", null }
                });

            migrationBuilder.InsertData(
                table: "GroupMembershipRequests",
                columns: new[] { "RequestId", "AdminComments", "EmployeeId", "GroupId", "ProcessedByUserId", "ProcessedDate", "RequestDate", "Status" },
                values: new object[,]
                {
                    { -4, "Did not meet department requirements.", -1, -2, null, new DateTime(2025, 6, 3, 8, 12, 24, 109, DateTimeKind.Utc).AddTicks(6018), new DateTime(2025, 6, 2, 8, 12, 24, 109, DateTimeKind.Utc).AddTicks(6017), "Rejected" },
                    { -3, null, -2, -1, null, new DateTime(2025, 6, 4, 8, 12, 24, 109, DateTimeKind.Utc).AddTicks(6011), new DateTime(2025, 6, 3, 8, 12, 24, 109, DateTimeKind.Utc).AddTicks(6010), "Approved" },
                    { -2, null, -2, -2, null, null, new DateTime(2025, 6, 5, 8, 12, 24, 109, DateTimeKind.Utc).AddTicks(6009), "Pending" },
                    { -1, null, -1, -1, null, null, new DateTime(2025, 6, 4, 8, 12, 24, 109, DateTimeKind.Utc).AddTicks(5998), "Pending" }
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "GroupMembershipRequests",
                keyColumn: "RequestId",
                keyValue: -4);

            migrationBuilder.DeleteData(
                table: "GroupMembershipRequests",
                keyColumn: "RequestId",
                keyValue: -3);

            migrationBuilder.DeleteData(
                table: "GroupMembershipRequests",
                keyColumn: "RequestId",
                keyValue: -2);

            migrationBuilder.DeleteData(
                table: "GroupMembershipRequests",
                keyColumn: "RequestId",
                keyValue: -1);

            migrationBuilder.DeleteData(
                table: "Employees",
                keyColumn: "EmpNO",
                keyValue: -2);

            migrationBuilder.DeleteData(
                table: "Employees",
                keyColumn: "EmpNO",
                keyValue: -1);

            migrationBuilder.DeleteData(
                table: "Groups",
                keyColumn: "Id",
                keyValue: -2);

            migrationBuilder.DeleteData(
                table: "Groups",
                keyColumn: "Id",
                keyValue: -1);

            migrationBuilder.InsertData(
                table: "Employees",
                columns: new[] { "EmpNO", "CreatedAt", "Department", "Email", "Name", "PhoneNumber", "Position", "UpdatedAt" },
                values: new object[] { 1, new DateTime(2025, 5, 29, 17, 39, 31, 589, DateTimeKind.Utc).AddTicks(5643), "IT", "test.employee@example.com", "Test Employee", null, "Developer", null });

            migrationBuilder.InsertData(
                table: "Groups",
                columns: new[] { "Id", "CreatedAt", "CreatedByUserId", "DepartmentRestriction", "Description", "IsPrivate", "MaxMembers", "Name", "UpdatedAt" },
                values: new object[] { 1, new DateTime(2025, 5, 29, 17, 39, 31, 589, DateTimeKind.Utc).AddTicks(5845), null, "IT", "A test group for membership requests", true, 10, "Test Group", null });

            migrationBuilder.InsertData(
                table: "GroupMembershipRequests",
                columns: new[] { "RequestId", "AdminComments", "EmployeeId", "GroupId", "ProcessedByUserId", "ProcessedDate", "RequestDate", "Status" },
                values: new object[] { 1, null, 1, 1, null, null, new DateTime(2025, 5, 29, 17, 39, 31, 589, DateTimeKind.Utc).AddTicks(5883), "Pending" });
        }
    }
}
