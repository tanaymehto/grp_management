﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace grp_management.Migrations
{
    /// <inheritdoc />
    public partial class MakeEmployeeIdNullableInContact : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Contacts_Employees_EmployeeId",
                table: "Contacts");

            migrationBuilder.AlterColumn<int>(
                name: "EmployeeId",
                table: "Contacts",
                type: "int",
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int");

            migrationBuilder.UpdateData(
                table: "Contacts",
                keyColumn: "Id",
                keyValue: -2,
                column: "AddedAt",
                value: new DateTime(2025, 6, 7, 9, 27, 51, 307, DateTimeKind.Utc).AddTicks(2565));

            migrationBuilder.UpdateData(
                table: "Contacts",
                keyColumn: "Id",
                keyValue: -1,
                column: "AddedAt",
                value: new DateTime(2025, 6, 7, 9, 27, 51, 307, DateTimeKind.Utc).AddTicks(2555));

            migrationBuilder.UpdateData(
                table: "Employees",
                keyColumn: "EmpNO",
                keyValue: -2,
                column: "CreatedAt",
                value: new DateTime(2025, 6, 7, 9, 27, 51, 306, DateTimeKind.Utc).AddTicks(9060));

            migrationBuilder.UpdateData(
                table: "Employees",
                keyColumn: "EmpNO",
                keyValue: -1,
                column: "CreatedAt",
                value: new DateTime(2025, 6, 7, 9, 27, 51, 306, DateTimeKind.Utc).AddTicks(9035));

            migrationBuilder.UpdateData(
                table: "GroupMembershipRequests",
                keyColumn: "RequestId",
                keyValue: -4,
                columns: new[] { "ProcessedDate", "RequestDate" },
                values: new object[] { new DateTime(2025, 6, 5, 9, 27, 51, 307, DateTimeKind.Utc).AddTicks(1471), new DateTime(2025, 6, 4, 9, 27, 51, 307, DateTimeKind.Utc).AddTicks(1469) });

            migrationBuilder.UpdateData(
                table: "GroupMembershipRequests",
                keyColumn: "RequestId",
                keyValue: -3,
                columns: new[] { "ProcessedDate", "RequestDate" },
                values: new object[] { new DateTime(2025, 6, 6, 9, 27, 51, 307, DateTimeKind.Utc).AddTicks(1459), new DateTime(2025, 6, 5, 9, 27, 51, 307, DateTimeKind.Utc).AddTicks(1457) });

            migrationBuilder.UpdateData(
                table: "GroupMembershipRequests",
                keyColumn: "RequestId",
                keyValue: -2,
                column: "RequestDate",
                value: new DateTime(2025, 6, 7, 9, 27, 51, 307, DateTimeKind.Utc).AddTicks(1452));

            migrationBuilder.UpdateData(
                table: "GroupMembershipRequests",
                keyColumn: "RequestId",
                keyValue: -1,
                column: "RequestDate",
                value: new DateTime(2025, 6, 6, 9, 27, 51, 307, DateTimeKind.Utc).AddTicks(1433));

            migrationBuilder.UpdateData(
                table: "Groups",
                keyColumn: "Id",
                keyValue: -2,
                column: "CreatedAt",
                value: new DateTime(2025, 6, 7, 9, 27, 51, 307, DateTimeKind.Utc).AddTicks(1214));

            migrationBuilder.UpdateData(
                table: "Groups",
                keyColumn: "Id",
                keyValue: -1,
                column: "CreatedAt",
                value: new DateTime(2025, 6, 7, 9, 27, 51, 307, DateTimeKind.Utc).AddTicks(1177));

            migrationBuilder.UpdateData(
                table: "SentMsgs",
                keyColumn: "SentMsgID",
                keyValue: -4,
                column: "SentDate",
                value: new DateTime(2025, 6, 7, 5, 27, 51, 307, DateTimeKind.Utc).AddTicks(3051));

            migrationBuilder.UpdateData(
                table: "SentMsgs",
                keyColumn: "SentMsgID",
                keyValue: -3,
                columns: new[] { "SentDate", "SentVia", "Status" },
                values: new object[] { new DateTime(2025, 6, 7, 6, 27, 51, 307, DateTimeKind.Utc).AddTicks(3047), "Email", "Sent" });

            migrationBuilder.UpdateData(
                table: "SentMsgs",
                keyColumn: "SentMsgID",
                keyValue: -2,
                column: "SentDate",
                value: new DateTime(2025, 6, 7, 7, 27, 51, 307, DateTimeKind.Utc).AddTicks(3042));

            migrationBuilder.UpdateData(
                table: "SentMsgs",
                keyColumn: "SentMsgID",
                keyValue: -1,
                column: "SentDate",
                value: new DateTime(2025, 6, 7, 8, 27, 51, 307, DateTimeKind.Utc).AddTicks(3022));

            migrationBuilder.InsertData(
                table: "Templates",
                columns: new[] { "TemplateID", "Placeholders", "TemplateMsg", "TemplateName", "TemplateType" },
                values: new object[,]
                {
                    { -2, "", "Reminder: Meeting at 11 AM. See you there!", "Meeting Reminder", "Frequent" },
                    { -1, "name", "Happy Birthday, {name}! Wishing you a wonderful day.", "Happy Birthday", "General" }
                });

            migrationBuilder.AddForeignKey(
                name: "FK_Contacts_Employees_EmployeeId",
                table: "Contacts",
                column: "EmployeeId",
                principalTable: "Employees",
                principalColumn: "EmpNO");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Contacts_Employees_EmployeeId",
                table: "Contacts");

            migrationBuilder.DeleteData(
                table: "Templates",
                keyColumn: "TemplateID",
                keyValue: -2);

            migrationBuilder.DeleteData(
                table: "Templates",
                keyColumn: "TemplateID",
                keyValue: -1);

            migrationBuilder.AlterColumn<int>(
                name: "EmployeeId",
                table: "Contacts",
                type: "int",
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(int),
                oldType: "int",
                oldNullable: true);

            migrationBuilder.UpdateData(
                table: "Contacts",
                keyColumn: "Id",
                keyValue: -2,
                column: "AddedAt",
                value: new DateTime(2025, 6, 7, 4, 54, 29, 367, DateTimeKind.Utc).AddTicks(7648));

            migrationBuilder.UpdateData(
                table: "Contacts",
                keyColumn: "Id",
                keyValue: -1,
                column: "AddedAt",
                value: new DateTime(2025, 6, 7, 4, 54, 29, 367, DateTimeKind.Utc).AddTicks(7640));

            migrationBuilder.UpdateData(
                table: "Employees",
                keyColumn: "EmpNO",
                keyValue: -2,
                column: "CreatedAt",
                value: new DateTime(2025, 6, 7, 4, 54, 29, 367, DateTimeKind.Utc).AddTicks(7291));

            migrationBuilder.UpdateData(
                table: "Employees",
                keyColumn: "EmpNO",
                keyValue: -1,
                column: "CreatedAt",
                value: new DateTime(2025, 6, 7, 4, 54, 29, 367, DateTimeKind.Utc).AddTicks(7284));

            migrationBuilder.UpdateData(
                table: "GroupMembershipRequests",
                keyColumn: "RequestId",
                keyValue: -4,
                columns: new[] { "ProcessedDate", "RequestDate" },
                values: new object[] { new DateTime(2025, 6, 5, 4, 54, 29, 367, DateTimeKind.Utc).AddTicks(7583), new DateTime(2025, 6, 4, 4, 54, 29, 367, DateTimeKind.Utc).AddTicks(7581) });

            migrationBuilder.UpdateData(
                table: "GroupMembershipRequests",
                keyColumn: "RequestId",
                keyValue: -3,
                columns: new[] { "ProcessedDate", "RequestDate" },
                values: new object[] { new DateTime(2025, 6, 6, 4, 54, 29, 367, DateTimeKind.Utc).AddTicks(7574), new DateTime(2025, 6, 5, 4, 54, 29, 367, DateTimeKind.Utc).AddTicks(7573) });

            migrationBuilder.UpdateData(
                table: "GroupMembershipRequests",
                keyColumn: "RequestId",
                keyValue: -2,
                column: "RequestDate",
                value: new DateTime(2025, 6, 7, 4, 54, 29, 367, DateTimeKind.Utc).AddTicks(7570));

            migrationBuilder.UpdateData(
                table: "GroupMembershipRequests",
                keyColumn: "RequestId",
                keyValue: -1,
                column: "RequestDate",
                value: new DateTime(2025, 6, 6, 4, 54, 29, 367, DateTimeKind.Utc).AddTicks(7560));

            migrationBuilder.UpdateData(
                table: "Groups",
                keyColumn: "Id",
                keyValue: -2,
                column: "CreatedAt",
                value: new DateTime(2025, 6, 7, 4, 54, 29, 367, DateTimeKind.Utc).AddTicks(7515));

            migrationBuilder.UpdateData(
                table: "Groups",
                keyColumn: "Id",
                keyValue: -1,
                column: "CreatedAt",
                value: new DateTime(2025, 6, 7, 4, 54, 29, 367, DateTimeKind.Utc).AddTicks(7507));

            migrationBuilder.UpdateData(
                table: "SentMsgs",
                keyColumn: "SentMsgID",
                keyValue: -4,
                column: "SentDate",
                value: new DateTime(2025, 6, 7, 0, 54, 29, 367, DateTimeKind.Utc).AddTicks(7697));

            migrationBuilder.UpdateData(
                table: "SentMsgs",
                keyColumn: "SentMsgID",
                keyValue: -3,
                columns: new[] { "SentDate", "SentVia", "Status" },
                values: new object[] { new DateTime(2025, 6, 7, 1, 54, 29, 367, DateTimeKind.Utc).AddTicks(7694), "SMS", "Failed" });

            migrationBuilder.UpdateData(
                table: "SentMsgs",
                keyColumn: "SentMsgID",
                keyValue: -2,
                column: "SentDate",
                value: new DateTime(2025, 6, 7, 2, 54, 29, 367, DateTimeKind.Utc).AddTicks(7691));

            migrationBuilder.UpdateData(
                table: "SentMsgs",
                keyColumn: "SentMsgID",
                keyValue: -1,
                column: "SentDate",
                value: new DateTime(2025, 6, 7, 3, 54, 29, 367, DateTimeKind.Utc).AddTicks(7686));

            migrationBuilder.AddForeignKey(
                name: "FK_Contacts_Employees_EmployeeId",
                table: "Contacts",
                column: "EmployeeId",
                principalTable: "Employees",
                principalColumn: "EmpNO",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
