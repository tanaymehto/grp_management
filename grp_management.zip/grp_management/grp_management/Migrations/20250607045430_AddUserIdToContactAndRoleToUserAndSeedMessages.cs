﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace grp_management.Migrations
{
    /// <inheritdoc />
    public partial class AddUserIdToContactAndRoleToUserAndSeedMessages : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "Role",
                table: "Users",
                type: "nvarchar(20)",
                maxLength: 20,
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<int>(
                name: "UserId",
                table: "Contacts",
                type: "int",
                nullable: true);

            migrationBuilder.UpdateData(
                table: "Employees",
                keyColumn: "EmpNO",
                keyValue: -2,
                column: "CreatedAt",
                value: new DateTime(2025, 6, 7, 4, 54, 29, 367, DateTimeKind.Utc).AddTicks(7291));

            migrationBuilder.UpdateData(
                table: "Employees",
                keyColumn: "EmpNO",
                keyValue: -1,
                column: "CreatedAt",
                value: new DateTime(2025, 6, 7, 4, 54, 29, 367, DateTimeKind.Utc).AddTicks(7284));

            migrationBuilder.UpdateData(
                table: "GroupMembershipRequests",
                keyColumn: "RequestId",
                keyValue: -4,
                columns: new[] { "ProcessedDate", "RequestDate" },
                values: new object[] { new DateTime(2025, 6, 5, 4, 54, 29, 367, DateTimeKind.Utc).AddTicks(7583), new DateTime(2025, 6, 4, 4, 54, 29, 367, DateTimeKind.Utc).AddTicks(7581) });

            migrationBuilder.UpdateData(
                table: "GroupMembershipRequests",
                keyColumn: "RequestId",
                keyValue: -3,
                columns: new[] { "ProcessedDate", "RequestDate" },
                values: new object[] { new DateTime(2025, 6, 6, 4, 54, 29, 367, DateTimeKind.Utc).AddTicks(7574), new DateTime(2025, 6, 5, 4, 54, 29, 367, DateTimeKind.Utc).AddTicks(7573) });

            migrationBuilder.UpdateData(
                table: "GroupMembershipRequests",
                keyColumn: "RequestId",
                keyValue: -2,
                column: "RequestDate",
                value: new DateTime(2025, 6, 7, 4, 54, 29, 367, DateTimeKind.Utc).AddTicks(7570));

            migrationBuilder.UpdateData(
                table: "GroupMembershipRequests",
                keyColumn: "RequestId",
                keyValue: -1,
                column: "RequestDate",
                value: new DateTime(2025, 6, 6, 4, 54, 29, 367, DateTimeKind.Utc).AddTicks(7560));

            migrationBuilder.UpdateData(
                table: "Groups",
                keyColumn: "Id",
                keyValue: -2,
                column: "CreatedAt",
                value: new DateTime(2025, 6, 7, 4, 54, 29, 367, DateTimeKind.Utc).AddTicks(7515));

            migrationBuilder.UpdateData(
                table: "Groups",
                keyColumn: "Id",
                keyValue: -1,
                column: "CreatedAt",
                value: new DateTime(2025, 6, 7, 4, 54, 29, 367, DateTimeKind.Utc).AddTicks(7507));

            migrationBuilder.InsertData(
                table: "Users",
                columns: new[] { "Id", "CreatedAt", "Email", "PasswordHash", "Role", "Username" },
                values: new object[,]
                {
                    { -2, new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), "user2@example.com", "hashedpassword2", "Member", "testuser2" },
                    { -1, new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), "user1@example.com", "hashedpassword1", "Admin", "testuser1" }
                });

            migrationBuilder.InsertData(
                table: "Contacts",
                columns: new[] { "Id", "AccessLevel", "AddedAt", "EmployeeId", "GroupId", "UserId", "UserName" },
                values: new object[,]
                {
                    { -2, "Member", new DateTime(2025, 6, 7, 4, 54, 29, 367, DateTimeKind.Utc).AddTicks(7648), -2, -2, -2, "testuser2" },
                    { -1, "Admin", new DateTime(2025, 6, 7, 4, 54, 29, 367, DateTimeKind.Utc).AddTicks(7640), -1, -1, -1, "testuser1" }
                });

            migrationBuilder.InsertData(
                table: "SentMsgs",
                columns: new[] { "SentMsgID", "GroupId", "MessageContent", "SenderId", "SentDate", "SentVia", "Status", "TemplateID" },
                values: new object[,]
                {
                    { -4, -2, "Important announcement.", -2, new DateTime(2025, 6, 7, 0, 54, 29, 367, DateTimeKind.Utc).AddTicks(7697), "Email", "Pending", null },
                    { -3, -1, "Meeting reminder for Test Group 1.", -1, new DateTime(2025, 6, 7, 1, 54, 29, 367, DateTimeKind.Utc).AddTicks(7694), "SMS", "Failed", null },
                    { -2, -2, "Welcome to Test Group 2!", -2, new DateTime(2025, 6, 7, 2, 54, 29, 367, DateTimeKind.Utc).AddTicks(7691), "WhatsApp", "Sent", null },
                    { -1, -1, "Hello Test Group 1!", -1, new DateTime(2025, 6, 7, 3, 54, 29, 367, DateTimeKind.Utc).AddTicks(7686), "Email", "Sent", null }
                });

            migrationBuilder.CreateIndex(
                name: "IX_Contacts_UserId",
                table: "Contacts",
                column: "UserId");

            migrationBuilder.AddForeignKey(
                name: "FK_Contacts_Users_UserId",
                table: "Contacts",
                column: "UserId",
                principalTable: "Users",
                principalColumn: "Id");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Contacts_Users_UserId",
                table: "Contacts");

            migrationBuilder.DropIndex(
                name: "IX_Contacts_UserId",
                table: "Contacts");

            migrationBuilder.DeleteData(
                table: "SentMsgs",
                keyColumn: "SentMsgID",
                keyValue: -4);

            migrationBuilder.DeleteData(
                table: "SentMsgs",
                keyColumn: "SentMsgID",
                keyValue: -3);

            migrationBuilder.DeleteData(
                table: "SentMsgs",
                keyColumn: "SentMsgID",
                keyValue: -2);

            migrationBuilder.DeleteData(
                table: "SentMsgs",
                keyColumn: "SentMsgID",
                keyValue: -1);

            migrationBuilder.DeleteData(
                table: "Contacts",
                keyColumn: "Id",
                keyValue: -2);

            migrationBuilder.DeleteData(
                table: "Contacts",
                keyColumn: "Id",
                keyValue: -1);

            migrationBuilder.DeleteData(
                table: "Users",
                keyColumn: "Id",
                keyValue: -2);

            migrationBuilder.DeleteData(
                table: "Users",
                keyColumn: "Id",
                keyValue: -1);

            migrationBuilder.DropColumn(
                name: "Role",
                table: "Users");

            migrationBuilder.DropColumn(
                name: "UserId",
                table: "Contacts");

            migrationBuilder.UpdateData(
                table: "Employees",
                keyColumn: "EmpNO",
                keyValue: -2,
                column: "CreatedAt",
                value: new DateTime(2025, 6, 7, 4, 47, 57, 857, DateTimeKind.Utc).AddTicks(2695));

            migrationBuilder.UpdateData(
                table: "Employees",
                keyColumn: "EmpNO",
                keyValue: -1,
                column: "CreatedAt",
                value: new DateTime(2025, 6, 7, 4, 47, 57, 857, DateTimeKind.Utc).AddTicks(2690));

            migrationBuilder.UpdateData(
                table: "GroupMembershipRequests",
                keyColumn: "RequestId",
                keyValue: -4,
                columns: new[] { "ProcessedDate", "RequestDate" },
                values: new object[] { new DateTime(2025, 6, 5, 4, 47, 57, 857, DateTimeKind.Utc).AddTicks(3013), new DateTime(2025, 6, 4, 4, 47, 57, 857, DateTimeKind.Utc).AddTicks(3012) });

            migrationBuilder.UpdateData(
                table: "GroupMembershipRequests",
                keyColumn: "RequestId",
                keyValue: -3,
                columns: new[] { "ProcessedDate", "RequestDate" },
                values: new object[] { new DateTime(2025, 6, 6, 4, 47, 57, 857, DateTimeKind.Utc).AddTicks(3005), new DateTime(2025, 6, 5, 4, 47, 57, 857, DateTimeKind.Utc).AddTicks(3004) });

            migrationBuilder.UpdateData(
                table: "GroupMembershipRequests",
                keyColumn: "RequestId",
                keyValue: -2,
                column: "RequestDate",
                value: new DateTime(2025, 6, 7, 4, 47, 57, 857, DateTimeKind.Utc).AddTicks(3001));

            migrationBuilder.UpdateData(
                table: "GroupMembershipRequests",
                keyColumn: "RequestId",
                keyValue: -1,
                column: "RequestDate",
                value: new DateTime(2025, 6, 6, 4, 47, 57, 857, DateTimeKind.Utc).AddTicks(2992));

            migrationBuilder.UpdateData(
                table: "Groups",
                keyColumn: "Id",
                keyValue: -2,
                column: "CreatedAt",
                value: new DateTime(2025, 6, 7, 4, 47, 57, 857, DateTimeKind.Utc).AddTicks(2960));

            migrationBuilder.UpdateData(
                table: "Groups",
                keyColumn: "Id",
                keyValue: -1,
                column: "CreatedAt",
                value: new DateTime(2025, 6, 7, 4, 47, 57, 857, DateTimeKind.Utc).AddTicks(2950));
        }
    }
}
