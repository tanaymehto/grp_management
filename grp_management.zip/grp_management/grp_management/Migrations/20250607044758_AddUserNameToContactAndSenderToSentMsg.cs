﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace grp_management.Migrations
{
    /// <inheritdoc />
    public partial class AddUserNameToContactAndSenderToSentMsg : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "SenderId",
                table: "SentMsgs",
                type: "int",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "UserName",
                table: "Contacts",
                type: "nvarchar(50)",
                maxLength: 50,
                nullable: false,
                defaultValue: "");

            migrationBuilder.UpdateData(
                table: "Employees",
                keyColumn: "EmpNO",
                keyValue: -2,
                column: "CreatedAt",
                value: new DateTime(2025, 6, 7, 4, 47, 57, 857, DateTimeKind.Utc).AddTicks(2695));

            migrationBuilder.UpdateData(
                table: "Employees",
                keyColumn: "EmpNO",
                keyValue: -1,
                column: "CreatedAt",
                value: new DateTime(2025, 6, 7, 4, 47, 57, 857, DateTimeKind.Utc).AddTicks(2690));

            migrationBuilder.UpdateData(
                table: "GroupMembershipRequests",
                keyColumn: "RequestId",
                keyValue: -4,
                columns: new[] { "ProcessedDate", "RequestDate" },
                values: new object[] { new DateTime(2025, 6, 5, 4, 47, 57, 857, DateTimeKind.Utc).AddTicks(3013), new DateTime(2025, 6, 4, 4, 47, 57, 857, DateTimeKind.Utc).AddTicks(3012) });

            migrationBuilder.UpdateData(
                table: "GroupMembershipRequests",
                keyColumn: "RequestId",
                keyValue: -3,
                columns: new[] { "ProcessedDate", "RequestDate" },
                values: new object[] { new DateTime(2025, 6, 6, 4, 47, 57, 857, DateTimeKind.Utc).AddTicks(3005), new DateTime(2025, 6, 5, 4, 47, 57, 857, DateTimeKind.Utc).AddTicks(3004) });

            migrationBuilder.UpdateData(
                table: "GroupMembershipRequests",
                keyColumn: "RequestId",
                keyValue: -2,
                column: "RequestDate",
                value: new DateTime(2025, 6, 7, 4, 47, 57, 857, DateTimeKind.Utc).AddTicks(3001));

            migrationBuilder.UpdateData(
                table: "GroupMembershipRequests",
                keyColumn: "RequestId",
                keyValue: -1,
                column: "RequestDate",
                value: new DateTime(2025, 6, 6, 4, 47, 57, 857, DateTimeKind.Utc).AddTicks(2992));

            migrationBuilder.UpdateData(
                table: "Groups",
                keyColumn: "Id",
                keyValue: -2,
                column: "CreatedAt",
                value: new DateTime(2025, 6, 7, 4, 47, 57, 857, DateTimeKind.Utc).AddTicks(2960));

            migrationBuilder.UpdateData(
                table: "Groups",
                keyColumn: "Id",
                keyValue: -1,
                column: "CreatedAt",
                value: new DateTime(2025, 6, 7, 4, 47, 57, 857, DateTimeKind.Utc).AddTicks(2950));

            migrationBuilder.CreateIndex(
                name: "IX_SentMsgs_SenderId",
                table: "SentMsgs",
                column: "SenderId");

            migrationBuilder.AddForeignKey(
                name: "FK_SentMsgs_Contacts_SenderId",
                table: "SentMsgs",
                column: "SenderId",
                principalTable: "Contacts",
                principalColumn: "Id");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_SentMsgs_Contacts_SenderId",
                table: "SentMsgs");

            migrationBuilder.DropIndex(
                name: "IX_SentMsgs_SenderId",
                table: "SentMsgs");

            migrationBuilder.DropColumn(
                name: "SenderId",
                table: "SentMsgs");

            migrationBuilder.DropColumn(
                name: "UserName",
                table: "Contacts");

            migrationBuilder.UpdateData(
                table: "Employees",
                keyColumn: "EmpNO",
                keyValue: -2,
                column: "CreatedAt",
                value: new DateTime(2025, 6, 5, 8, 12, 24, 109, DateTimeKind.Utc).AddTicks(5853));

            migrationBuilder.UpdateData(
                table: "Employees",
                keyColumn: "EmpNO",
                keyValue: -1,
                column: "CreatedAt",
                value: new DateTime(2025, 6, 5, 8, 12, 24, 109, DateTimeKind.Utc).AddTicks(5846));

            migrationBuilder.UpdateData(
                table: "GroupMembershipRequests",
                keyColumn: "RequestId",
                keyValue: -4,
                columns: new[] { "ProcessedDate", "RequestDate" },
                values: new object[] { new DateTime(2025, 6, 3, 8, 12, 24, 109, DateTimeKind.Utc).AddTicks(6018), new DateTime(2025, 6, 2, 8, 12, 24, 109, DateTimeKind.Utc).AddTicks(6017) });

            migrationBuilder.UpdateData(
                table: "GroupMembershipRequests",
                keyColumn: "RequestId",
                keyValue: -3,
                columns: new[] { "ProcessedDate", "RequestDate" },
                values: new object[] { new DateTime(2025, 6, 4, 8, 12, 24, 109, DateTimeKind.Utc).AddTicks(6011), new DateTime(2025, 6, 3, 8, 12, 24, 109, DateTimeKind.Utc).AddTicks(6010) });

            migrationBuilder.UpdateData(
                table: "GroupMembershipRequests",
                keyColumn: "RequestId",
                keyValue: -2,
                column: "RequestDate",
                value: new DateTime(2025, 6, 5, 8, 12, 24, 109, DateTimeKind.Utc).AddTicks(6009));

            migrationBuilder.UpdateData(
                table: "GroupMembershipRequests",
                keyColumn: "RequestId",
                keyValue: -1,
                column: "RequestDate",
                value: new DateTime(2025, 6, 4, 8, 12, 24, 109, DateTimeKind.Utc).AddTicks(5998));

            migrationBuilder.UpdateData(
                table: "Groups",
                keyColumn: "Id",
                keyValue: -2,
                column: "CreatedAt",
                value: new DateTime(2025, 6, 5, 8, 12, 24, 109, DateTimeKind.Utc).AddTicks(5975));

            migrationBuilder.UpdateData(
                table: "Groups",
                keyColumn: "Id",
                keyValue: -1,
                column: "CreatedAt",
                value: new DateTime(2025, 6, 5, 8, 12, 24, 109, DateTimeKind.Utc).AddTicks(5969));
        }
    }
}
