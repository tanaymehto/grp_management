using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using grp_management.Data;
using grp_management.Models;
using System.Text.Json;
using Microsoft.EntityFrameworkCore;

namespace grp_management.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize(Roles = "Admin")]
    public class TemplatesController : ControllerBase
    {
        private readonly AppDbContext _context;
        private readonly ILogger<TemplatesController> _logger;

        public TemplatesController(AppDbContext context, ILogger<TemplatesController> logger)
        {
            _context = context;
            _logger = logger;
        }

        [HttpPost]
        public async Task<IActionResult> CreateTemplate([FromBody] Template template)
        {
            try
            {
                if (template.TemplateID > 0)
                {
                    // Update existing template
                    var existingTemplate = await _context.Templates.FindAsync(template.TemplateID);
                    if (existingTemplate == null)
                    {
                        return NotFound(new { message = "Template not found" });
                    }

                    existingTemplate.TemplateName = template.TemplateName;
                    existingTemplate.TemplateMsg = template.TemplateMsg;
                    existingTemplate.TemplateType = template.TemplateType;
                    existingTemplate.Placeholders = template.Placeholders;

                    _context.Templates.Update(existingTemplate);
                }
                else
                {
                    // Create new template
                    _context.Templates.Add(template);
                }

                await _context.SaveChangesAsync();
                return Ok(new { message = "Template saved successfully" });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error saving template");
                return StatusCode(500, new { message = "An error occurred while saving the template" });
            }
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteTemplate(int id)
        {
            try
            {
                var template = await _context.Templates.FindAsync(id);
                if (template == null)
                {
                    return NotFound(new { message = "Template not found" });
                }

                _context.Templates.Remove(template);
                await _context.SaveChangesAsync();

                return Ok(new { message = "Template deleted successfully" });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error deleting template");
                return StatusCode(500, new { message = "An error occurred while deleting the template" });
            }
        }

        [HttpGet]
        [AllowAnonymous]
        public async Task<IActionResult> GetTemplates()
        {
            try
            {
                var templates = await _context.Templates.ToListAsync();
                return Ok(templates);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error retrieving templates");
                return StatusCode(500, new { message = "An error occurred while retrieving templates" });
            }
        }
    }
} 