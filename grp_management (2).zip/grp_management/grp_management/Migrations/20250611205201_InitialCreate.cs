﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace grp_management.Migrations
{
    /// <inheritdoc />
    public partial class InitialCreate : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Employees",
                columns: table => new
                {
                    EmpNO = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    Email = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    PhoneNumber = table.Column<string>(type: "nvarchar(20)", maxLength: 20, nullable: true),
                    Department = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    Position = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    CreatedAt = table.Column<DateTime>(type: "datetime2", nullable: false),
                    UpdatedAt = table.Column<DateTime>(type: "datetime2", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Employees", x => x.EmpNO);
                });

            migrationBuilder.CreateTable(
                name: "MessageTemplates",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    Content = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Description = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    Type = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    Placeholders = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    CreatedAt = table.Column<DateTime>(type: "datetime2", nullable: false),
                    UpdatedAt = table.Column<DateTime>(type: "datetime2", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_MessageTemplates", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Templates",
                columns: table => new
                {
                    TemplateID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    TemplateName = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    TemplateMsg = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    TemplateType = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Placeholders = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Templates", x => x.TemplateID);
                });

            migrationBuilder.CreateTable(
                name: "Users",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Username = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    PasswordHash = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    Email = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    Role = table.Column<string>(type: "nvarchar(20)", maxLength: 20, nullable: false),
                    CreatedAt = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Users", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Groups",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    Description = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: true),
                    IsPrivate = table.Column<bool>(type: "bit", nullable: false),
                    MaxMembers = table.Column<int>(type: "int", nullable: true),
                    DepartmentRestriction = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    CreatedAt = table.Column<DateTime>(type: "datetime2", nullable: false),
                    UpdatedAt = table.Column<DateTime>(type: "datetime2", nullable: true),
                    CreatedByUserId = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Groups", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Groups_Users_CreatedByUserId",
                        column: x => x.CreatedByUserId,
                        principalTable: "Users",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.SetNull);
                });

            migrationBuilder.CreateTable(
                name: "Contacts",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    GroupId = table.Column<int>(type: "int", nullable: false),
                    EmployeeId = table.Column<int>(type: "int", nullable: true),
                    UserName = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    AccessLevel = table.Column<string>(type: "nvarchar(20)", maxLength: 20, nullable: false, defaultValue: "Member"),
                    AddedAt = table.Column<DateTime>(type: "datetime2", nullable: false),
                    UserId = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Contacts", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Contacts_Employees_EmployeeId",
                        column: x => x.EmployeeId,
                        principalTable: "Employees",
                        principalColumn: "EmpNO");
                    table.ForeignKey(
                        name: "FK_Contacts_Groups_GroupId",
                        column: x => x.GroupId,
                        principalTable: "Groups",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_Contacts_Users_UserId",
                        column: x => x.UserId,
                        principalTable: "Users",
                        principalColumn: "Id");
                });

            migrationBuilder.CreateTable(
                name: "GroupEmployees",
                columns: table => new
                {
                    GroupId = table.Column<int>(type: "int", nullable: false),
                    EmployeeId = table.Column<int>(type: "int", nullable: false),
                    Id = table.Column<int>(type: "int", nullable: false),
                    AddedAt = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_GroupEmployees", x => new { x.GroupId, x.EmployeeId });
                    table.ForeignKey(
                        name: "FK_GroupEmployees_Employees_EmployeeId",
                        column: x => x.EmployeeId,
                        principalTable: "Employees",
                        principalColumn: "EmpNO",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_GroupEmployees_Groups_GroupId",
                        column: x => x.GroupId,
                        principalTable: "Groups",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "GroupMembershipRequests",
                columns: table => new
                {
                    RequestId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    GroupId = table.Column<int>(type: "int", nullable: false),
                    EmployeeId = table.Column<int>(type: "int", nullable: false),
                    RequestDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Status = table.Column<string>(type: "nvarchar(20)", maxLength: 20, nullable: false, defaultValue: "Pending"),
                    AdminComments = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ProcessedByUserId = table.Column<int>(type: "int", nullable: true),
                    ProcessedDate = table.Column<DateTime>(type: "datetime2", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_GroupMembershipRequests", x => x.RequestId);
                    table.ForeignKey(
                        name: "FK_GroupMembershipRequests_Employees_EmployeeId",
                        column: x => x.EmployeeId,
                        principalTable: "Employees",
                        principalColumn: "EmpNO",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_GroupMembershipRequests_Groups_GroupId",
                        column: x => x.GroupId,
                        principalTable: "Groups",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_GroupMembershipRequests_Users_ProcessedByUserId",
                        column: x => x.ProcessedByUserId,
                        principalTable: "Users",
                        principalColumn: "Id");
                });

            migrationBuilder.CreateTable(
                name: "Messages",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    GroupId = table.Column<int>(type: "int", nullable: false),
                    SentVia = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    MessageContent = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Status = table.Column<string>(type: "nvarchar(20)", maxLength: 20, nullable: false),
                    CreatedAt = table.Column<DateTime>(type: "datetime2", nullable: false),
                    SentAt = table.Column<DateTime>(type: "datetime2", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Messages", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Messages_Groups_GroupId",
                        column: x => x.GroupId,
                        principalTable: "Groups",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "SentMsgs",
                columns: table => new
                {
                    SentMsgID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    MessageContent = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    SentDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    SentVia = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    Status = table.Column<string>(type: "nvarchar(20)", maxLength: 20, nullable: false),
                    GroupId = table.Column<int>(type: "int", nullable: false),
                    TemplateID = table.Column<int>(type: "int", nullable: true),
                    SenderId = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_SentMsgs", x => x.SentMsgID);
                    table.ForeignKey(
                        name: "FK_SentMsgs_Contacts_SenderId",
                        column: x => x.SenderId,
                        principalTable: "Contacts",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_SentMsgs_Groups_GroupId",
                        column: x => x.GroupId,
                        principalTable: "Groups",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_SentMsgs_Templates_TemplateID",
                        column: x => x.TemplateID,
                        principalTable: "Templates",
                        principalColumn: "TemplateID");
                });

            migrationBuilder.InsertData(
                table: "Employees",
                columns: new[] { "EmpNO", "CreatedAt", "Department", "Email", "Name", "PhoneNumber", "Position", "UpdatedAt" },
                values: new object[,]
                {
                    { -2, new DateTime(2025, 6, 11, 20, 52, 0, 465, DateTimeKind.Utc).AddTicks(8369), "HR", "test.employee2@example.com", "Test Employee 2", null, "Assistant", null },
                    { -1, new DateTime(2025, 6, 11, 20, 52, 0, 465, DateTimeKind.Utc).AddTicks(8366), "IT", "test.employee1@example.com", "Test Employee 1", null, "Developer", null }
                });

            migrationBuilder.InsertData(
                table: "Groups",
                columns: new[] { "Id", "CreatedAt", "CreatedByUserId", "DepartmentRestriction", "Description", "IsPrivate", "MaxMembers", "Name", "UpdatedAt" },
                values: new object[,]
                {
                    { -2, new DateTime(2025, 6, 11, 20, 52, 0, 465, DateTimeKind.Utc).AddTicks(8535), null, "HR", "Another test group", false, 20, "Test Group 2", null },
                    { -1, new DateTime(2025, 6, 11, 20, 52, 0, 465, DateTimeKind.Utc).AddTicks(8532), null, "IT", "A test group for membership requests", true, 10, "Test Group 1", null }
                });

            migrationBuilder.InsertData(
                table: "Templates",
                columns: new[] { "TemplateID", "Placeholders", "TemplateMsg", "TemplateName", "TemplateType" },
                values: new object[,]
                {
                    { -2, "{}", "Reminder: Meeting at 11 AM. See you there!", "Meeting Reminder", "Frequent" },
                    { -1, "{\"Name\":\"Recipient Name\"}", "Happy Birthday, {{Name}}! Wishing you a wonderful day.", "Happy Birthday", "General" }
                });

            migrationBuilder.InsertData(
                table: "Users",
                columns: new[] { "Id", "CreatedAt", "Email", "PasswordHash", "Role", "Username" },
                values: new object[,]
                {
                    { -2, new DateTime(2025, 6, 11, 20, 52, 1, 113, DateTimeKind.Utc).AddTicks(8975), "user@example.com", "$2a$12$FYjI0Z/RRIAf3ictCFrJeeNF9Ig6MqY7KWeB3EV1YV2upY8IUenjC", "User", "user" },
                    { -1, new DateTime(2025, 6, 11, 20, 52, 0, 791, DateTimeKind.Utc).AddTicks(2667), "admin@example.com", "$2a$12$M0wAmS/3AwosDkLPyLBeSOVcczHj744FvZyY1VvbouVXWUj2HSefK", "Admin", "admin" }
                });

            migrationBuilder.InsertData(
                table: "Contacts",
                columns: new[] { "Id", "AccessLevel", "AddedAt", "EmployeeId", "GroupId", "UserId", "UserName" },
                values: new object[,]
                {
                    { -2, "Member", new DateTime(2025, 6, 11, 20, 52, 1, 113, DateTimeKind.Utc).AddTicks(9845), -2, -2, -2, "testuser2" },
                    { -1, "Admin", new DateTime(2025, 6, 11, 20, 52, 1, 113, DateTimeKind.Utc).AddTicks(9842), -1, -1, -1, "testuser1" }
                });

            migrationBuilder.InsertData(
                table: "GroupMembershipRequests",
                columns: new[] { "RequestId", "AdminComments", "EmployeeId", "GroupId", "ProcessedByUserId", "ProcessedDate", "RequestDate", "Status" },
                values: new object[,]
                {
                    { -4, "Did not meet department requirements.", -1, -2, null, new DateTime(2025, 6, 9, 20, 52, 0, 465, DateTimeKind.Utc).AddTicks(8584), new DateTime(2025, 6, 8, 20, 52, 0, 465, DateTimeKind.Utc).AddTicks(8584), "Rejected" },
                    { -3, null, -2, -1, null, new DateTime(2025, 6, 10, 20, 52, 0, 465, DateTimeKind.Utc).AddTicks(8578), new DateTime(2025, 6, 9, 20, 52, 0, 465, DateTimeKind.Utc).AddTicks(8577), "Approved" },
                    { -2, null, -2, -2, null, null, new DateTime(2025, 6, 11, 20, 52, 0, 465, DateTimeKind.Utc).AddTicks(8569), "Pending" },
                    { -1, null, -1, -1, null, null, new DateTime(2025, 6, 10, 20, 52, 0, 465, DateTimeKind.Utc).AddTicks(8560), "Pending" }
                });

            migrationBuilder.InsertData(
                table: "SentMsgs",
                columns: new[] { "SentMsgID", "GroupId", "MessageContent", "SenderId", "SentDate", "SentVia", "Status", "TemplateID" },
                values: new object[,]
                {
                    { -4, -2, "Important announcement.", -2, new DateTime(2025, 6, 11, 16, 52, 1, 114, DateTimeKind.Utc).AddTicks(34), "Email", "Pending", null },
                    { -3, -1, "Meeting reminder for Test Group 1.", -1, new DateTime(2025, 6, 11, 17, 52, 1, 114, DateTimeKind.Utc).AddTicks(31), "Email", "Sent", null },
                    { -2, -2, "Welcome to Test Group 2!", -2, new DateTime(2025, 6, 11, 18, 52, 1, 113, DateTimeKind.Utc).AddTicks(9904), "WhatsApp", "Sent", null },
                    { -1, -1, "Hello Test Group 1!", -1, new DateTime(2025, 6, 11, 19, 52, 1, 113, DateTimeKind.Utc).AddTicks(9888), "Email", "Sent", null }
                });

            migrationBuilder.CreateIndex(
                name: "IX_Contacts_EmployeeId",
                table: "Contacts",
                column: "EmployeeId");

            migrationBuilder.CreateIndex(
                name: "IX_Contacts_GroupId",
                table: "Contacts",
                column: "GroupId");

            migrationBuilder.CreateIndex(
                name: "IX_Contacts_UserId",
                table: "Contacts",
                column: "UserId");

            migrationBuilder.CreateIndex(
                name: "IX_Employees_Email",
                table: "Employees",
                column: "Email",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_GroupEmployees_EmployeeId",
                table: "GroupEmployees",
                column: "EmployeeId");

            migrationBuilder.CreateIndex(
                name: "IX_GroupMembershipRequests_EmployeeId",
                table: "GroupMembershipRequests",
                column: "EmployeeId");

            migrationBuilder.CreateIndex(
                name: "IX_GroupMembershipRequests_GroupId",
                table: "GroupMembershipRequests",
                column: "GroupId");

            migrationBuilder.CreateIndex(
                name: "IX_GroupMembershipRequests_ProcessedByUserId",
                table: "GroupMembershipRequests",
                column: "ProcessedByUserId");

            migrationBuilder.CreateIndex(
                name: "IX_Groups_CreatedByUserId",
                table: "Groups",
                column: "CreatedByUserId");

            migrationBuilder.CreateIndex(
                name: "IX_Groups_Name",
                table: "Groups",
                column: "Name",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_Messages_GroupId",
                table: "Messages",
                column: "GroupId");

            migrationBuilder.CreateIndex(
                name: "IX_SentMsgs_GroupId",
                table: "SentMsgs",
                column: "GroupId");

            migrationBuilder.CreateIndex(
                name: "IX_SentMsgs_SenderId",
                table: "SentMsgs",
                column: "SenderId");

            migrationBuilder.CreateIndex(
                name: "IX_SentMsgs_TemplateID",
                table: "SentMsgs",
                column: "TemplateID");

            migrationBuilder.CreateIndex(
                name: "IX_Users_Username",
                table: "Users",
                column: "Username",
                unique: true);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "GroupEmployees");

            migrationBuilder.DropTable(
                name: "GroupMembershipRequests");

            migrationBuilder.DropTable(
                name: "Messages");

            migrationBuilder.DropTable(
                name: "MessageTemplates");

            migrationBuilder.DropTable(
                name: "SentMsgs");

            migrationBuilder.DropTable(
                name: "Contacts");

            migrationBuilder.DropTable(
                name: "Templates");

            migrationBuilder.DropTable(
                name: "Employees");

            migrationBuilder.DropTable(
                name: "Groups");

            migrationBuilder.DropTable(
                name: "Users");
        }
    }
}
