using Microsoft.AspNetCore.Mvc.RazorPages;

namespace grp_management.Pages
{
    public class UserManagementModel : PageModel
    {
        public void OnGet()
        {
        }
    }
} 