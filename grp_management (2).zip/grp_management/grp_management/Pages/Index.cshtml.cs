using Microsoft.AspNetCore.Mvc.RazorPages;
using grp_management.Data;
using grp_management.Models;
using System.Linq;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;

namespace grp_management.Pages
{
    public class IndexModel : PageModel
    {
        private readonly ILogger<IndexModel> _logger;
        private readonly AppDbContext _context;

        public Dictionary<string, int> MonthlyMessageCounts { get; set; } = new Dictionary<string, int>();
        public Dictionary<string, int> MessagesBySentVia { get; set; } = new Dictionary<string, int>();
        // Use a dynamic type or a simple class to avoid serialization cycles
        public List<object> RecentMessages { get; set; } = new List<object>();
        public Dictionary<string, int> MessagesPerGroup { get; set; } = new Dictionary<string, int>();
        public Dictionary<string, int> MessagesSentByUser { get; set; } = new Dictionary<string, int>();

        public IndexModel(ILogger<IndexModel> logger, AppDbContext context)
        {
            _logger = logger;
            _context = context;
        }

        public async Task OnGetAsync()
        {
            // Fetch data for Monthly Message Count
            MonthlyMessageCounts = await _context.SentMsgs
                .GroupBy(m => new { m.SentDate.Year, m.SentDate.Month })
                .OrderBy(g => g.Key.Year).ThenBy(g => g.Key.Month)
                .Select(g => new { Month = $"{g.Key.Year}-{g.Key.Month:D2}", Count = g.Count() })
                .ToDictionaryAsync(x => x.Month, x => x.Count);

            // Fetch data for Messages by Sent Via
            MessagesBySentVia = await _context.SentMsgs
                .Where(m => m.SentVia != null && m.SentVia != "") // Filter out null or empty SentVia
                .GroupBy(m => m.SentVia)
                .Select(g => new { SentVia = g.Key, Count = g.Count() })
                .ToDictionaryAsync(x => x.SentVia, x => x.Count);

            // Fetch data for Recent Messages (e.g., last 4)
            RecentMessages = await _context.SentMsgs
                .Include(s => s.Group)
                .OrderByDescending(m => m.SentDate)
                .Take(4)
                .Select(s => new 
                {
                    SentDate = s.SentDate.ToString("o"), // Format as ISO 8601 string
                    GroupName = s.Group!.Name, // Apply null-forgiving operator as Group is included
                    s.SentVia,
                    s.MessageContent,
                    s.Status
                })
                .Cast<object>() // Cast to object to store in List<object>
                .ToListAsync();

            // Fetch data for Messages sent by each user
            MessagesSentByUser = await _context.SentMsgs
                .Include(s => s.Sender)
                .Where(s => s.Sender != null && s.Sender.UserName != null)
                .GroupBy(s => s.Sender!.UserName!)
                .Select(g => new { UserName = g.Key, Count = g.Count() })
                .ToDictionaryAsync(x => x.UserName, x => x.Count);

            // Fetch data for Messages per Group for the logged-in user
            var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);
            if (userId != null)
            {
                MessagesPerGroup = await _context.SentMsgs
                    .Include(s => s.Group)
                    .Where(s => s.Group != null && s.Group.GroupEmployees.Any(ge => ge.EmployeeId == int.Parse(userId)))
                    .GroupBy(s => s.Group!.Name!)
                    .Select(g => new { GroupName = g.Key, Count = g.Count() })
                    .ToDictionaryAsync(x => x.GroupName, x => x.Count);
            }
        }
    }
}
