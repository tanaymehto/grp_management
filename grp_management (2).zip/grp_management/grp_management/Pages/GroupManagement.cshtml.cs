using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Authorization;

namespace grp_management.Pages
{
    [Authorize(Roles = "Admin")]
    public class GroupManagementModel : PageModel
    {
        public void OnGet()
        {
        }
    }
} 