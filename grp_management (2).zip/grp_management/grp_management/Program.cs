using Microsoft.AspNetCore.Authentication.Cookies;
using grp_management.Models;
using Microsoft.EntityFrameworkCore;
using System.Security.Cryptography;
using System.Text;
using grp_management.Hubs;
using grp_management.Data;
using System.Security.Claims;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddRazorPages();
builder.Services.AddControllers();

// Add IHttpContextAccessor
builder.Services.AddHttpContextAccessor();

// Add AppDbContext for EF Core
builder.Services.AddDbContext<AppDbContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));

// Add Authentication
builder.Services.AddAuthentication(CookieAuthenticationDefaults.AuthenticationScheme)
    .AddCookie(options =>
    {
        options.LoginPath = "/Login";
        options.LogoutPath = "/Logout";
        options.AccessDeniedPath = "/AccessDenied";
    });

// Add SignalR
builder.Services.AddSignalR();

var app = builder.Build();

// Seed or update sample user and groups
using (var scope = app.Services.CreateScope())
{
    var db = scope.ServiceProvider.GetRequiredService<AppDbContext>();
    db.Database.Migrate();

    // Ensure admin and user accounts exist
    // This logic is now handled in AppDbContext.cs SeedTestData method
    /*
    using (var scope = app.Services.CreateScope())
    {
        var services = scope.ServiceProvider;
        var context = services.GetRequiredService<AppDbContext>();

        context.Database.Migrate();

        if (!context.Users.Any())
        {
            // Hash passwords using BCrypt
            var adminPasswordHash = BCrypt.Net.BCrypt.HashPassword("password", 12);
            var userPasswordHash = BCrypt.Net.BCrypt.HashPassword("password", 12);

            context.Users.AddRange(
                new User { Username = "admin", PasswordHash = adminPasswordHash, Email = "admin@example.com", Role = "Admin", CreatedAt = DateTime.UtcNow },
                new User { Username = "user", PasswordHash = userPasswordHash, Email = "user@example.com", Role = "User", CreatedAt = DateTime.UtcNow }
            );
            context.SaveChanges();
        }
    }
    */

    // Seed default and specific groups if they don't exist
    EnsureGroupsExist(app.Services);

    // Seed a default template if none exists
    if (!db.Templates.Any())
    {
        db.Templates.Add(new Template { TemplateName = "Default Template", TemplateMsg = "This is a default message.", TemplateType = "General" });
        db.SaveChanges();
    }
}

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error");
    app.UseHsts();
}
app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

app.UseAuthentication();
app.UseAuthorization();

app.MapRazorPages();
app.MapControllers();
app.MapHub<MessageHub>("/messageHub");

app.Run();

void EnsureGroupsExist(IServiceProvider services)
{
    using (var scope = services.CreateScope())
    {
        var context = scope.ServiceProvider.GetRequiredService<AppDbContext>();
        var groupNamesToSeed = new List<string>
        {
            "Default Group",
            "DMP",
            "All Executive",
            "Young Executive",
            "Non Executive",
            "Worker",
            "IP Club Member",
            "RC Club Member",
            "Sports Council Members",
            "SMC Members",
            "HODs",
            "GMs",
            "AGMs",
            "Senior Manager and below(combined)"
        };

        foreach (var groupName in groupNamesToSeed)
        {
            if (!context.Groups.Any(g => g.Name == groupName))
            {
                context.Groups.Add(new Group { Name = groupName, Description = $"Group for {groupName}" });
            }
        }
        context.SaveChanges();
    }
}
